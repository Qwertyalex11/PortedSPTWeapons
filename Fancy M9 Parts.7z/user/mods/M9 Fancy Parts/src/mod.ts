import { DependencyContainer } from "tsyringe";

// SPT types
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { PreSptModLoader } from "@spt/loaders/PreSptModLoader";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { ImporterUtil } from "@spt/utils/ImporterUtil";
import { ImageRouter } from "@spt/routers/ImageRouter";
import { CustomTraderAssortData } from "../models/spt/services/CustomTraderAssortData";
import { ConfigServer } from "@spt/servers/ConfigServer";
import { ConfigTypes } from "@spt/models/enums/ConfigTypes";
import { ITraderAssort, ITraderBase } from "@spt/models/eft/common/tables/ITrader";
import { ITraderConfig, UpdateTime } from "@spt/models/spt/config/ITraderConfig";
import { JsonUtil } from "@spt/utils/JsonUtil";
import { Traders } from "@spt/models/enums/Traders";
import { Item } from "@spt/models/eft/common/tables/IItem";
import { IPreSptLoadMod } from "@spt/models/external/IPreSptLoadMod";
import { IPostSptLoadMod } from "@spt/models/external/IPostSptLoadMod";
import { ILocaleGlobalBase } from "@spt/models/spt/server/ILocaleBase";
import { IInvConfigConfig } from "@spt/models/spt/config/IInvConfigConfig";

class FancyM9
{
	private tables;
	private logger;
	
    public preSptLoad(container: DependencyContainer): void {
    this.logger = container.resolve<ILogger>("WinstonLogger");		
    this.logger.logWithColor("FancyM9 Loaded", "green");
    }

    public postDBLoad(container: DependencyContainer)
    {
		this.logger = container.resolve<ILogger>("WinstonLogger");			
		const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
		this.tables = databaseServer.getTables();
		const locales = Object.values(this.tables.locales.global) as ILocaleGlobalBase[];
        const preSptModLoader = container.resolve<PreSptModLoader>("PreSptModLoader");
		const ImporterUtil = container.resolve<ImporterUtil>("ImporterUtil");
        const db = ImporterUtil.loadRecursive(`${preSptModLoader.getModPath("M9 Fancy Parts")}db/`);
		
		//Issue might be with item IDs? Not referencing correctly?
		
		//Add Mod Items
		for (const item in db.items) {
			this.tables.templates.items[item] = db.items[item];
			this.logger.logWithColor((db.items[item]._id) + " Loaded into DB", "green");
		}
		//Add Locales
		for (const locale of locales) {
			//Add Item Descriptions
            for(const item in db.locales["en"].templates){
                locale[(item + " Name")] = db.locales["en"].templates[item].Name;
				locale[(item + " ShortName")] = db.locales["en"].templates[item].ShortName;
				locale[(item + " Description")] = db.locales["en"].templates[item].Description;
				//this.logger.logWithColor((db.locales["en"].templates[item].ShortName) + " Loaded into Locales", "green");
            }
		}
		//Add Items to Handbook
		for (const ha in db.templates.handbook) {
			this.tables.templates.handbook.Items.push(db.templates.handbook[ha]);
			this.logger.logWithColor((db.templates.handbook[ha].Id) + " Loaded into Handbook", "green");
		}
		
		//Add weapon presets
		for (const preset in db.templates.presets)
		{
			this.tables.globals.ItemPresets[db.templates.presets[preset]._id] = db.templates.presets[preset];
			this.logger.logWithColor((db.templates.presets[preset]._name) + " Loaded into Presets", "green");
		}
		//Add to relevant filters by treating it as old items
		for (const ItemKVP in db.templates.addToFilters)
		{
			this.logger.logWithColor(("About to try to treat " + (db.templates.addToFilters[ItemKVP].newItemID) + " as " + (db.templates.addToFilters[ItemKVP].treatAs)),"green");
			this.addToExistingItems(db.templates.addToFilters[ItemKVP].newItemID, db.templates.addToFilters[ItemKVP].treatAs);
			//this.logger.logWithColor("I should've just pushed something to a filter!", "green");
		}
		
		//Add to Traders
		for (const newitems in db.traders) {
            for (const item in db.traders[newitems].assort.items) {
                this.tables.traders[newitems].assort.items.unshift(db.traders[newitems].assort.items[item])
            }

            for (const item in db.traders[newitems].assort.barter_scheme) {
                this.tables.traders[newitems].assort.barter_scheme[item] =db.traders[newitems].assort.barter_scheme[item]
            }

            for (const item in db.traders[newitems].assort.loyal_level_items) {
                this.tables.traders[newitems].assort.loyal_level_items[item] = db.traders[newitems].assort.loyal_level_items[item]
            }
        }
		//Old Add Locales
		/*for (const lang in db.locales){				
			for (const item in db.locales[lang].templates)
				this.tables.locales.global[lang].templates[item] = db.locales[lang].templates[item];
		}*/
    }    

	private addToExistingItems(newItemID: string, itemToCopy: string): void {
		//Check if it goes in slots
		//this.logger.logWithColor(("Trying to treat " + newItemID + " as " + itemToCopy),"green");
		for (const oldItem in this.tables.templates.items) {
			if (this.tables.templates.items[oldItem]._props.Slots) {
				for (const slot in this.tables.templates.items[oldItem]._props.Slots) {
					for (const filter in this.tables.templates.items[oldItem]._props.Slots[slot]._props.filters[0].Filter) {					
						if (this.tables.templates.items[oldItem]._props.Slots[slot]._props.filters[0].Filter[filter] == itemToCopy) {
							this.tables.templates.items[oldItem]._props.Slots[slot]._props.filters[0].Filter.push(newItemID);
							//this.logger.logWithColor("I just pushed something to a Slot filter!", "green");
						}
					}
				}
			}
			if (this.tables.templates.items[oldItem]._props.Chambers) {
				for (const slot in this.tables.templates.items[oldItem]._props.Chambers) {
					for (const filter in this.tables.templates.items[oldItem]._props.Chambers[slot]._props.filters[0].Filter) {				
						if (this.tables.templates.items[oldItem]._props.Chambers[slot]._props.filters[0].Filter[filter] == itemToCopy) {
							this.tables.templates.items[oldItem]._props.Chambers[slot]._props.filters[0].Filter.push(newItemID);
							//this.logger.logWithColor("I just pushed something to a Chamber filter!", "green");
						}
					}
				}
			}
			if (this.tables.templates.items[oldItem]._props.Cartridges) {
				for (const slot in this.tables.templates.items[oldItem]._props.Cartridges) {
					for (const filter in this.tables.templates.items[oldItem]._props.Cartridges[slot]._props.filters[0].Filter) {
						if (this.tables.templates.items[oldItem]._props.Cartridges[slot]._props.filters[0].Filter[filter] == itemToCopy) {
							this.tables.templates.items[oldItem]._props.Cartridges[slot]._props.filters[0].Filter.push(newItemID);
							//this.logger.logWithColor("I just pushed something to a Cartridge filter!", "green");
						}
					}
				}
			}
		}
	}
}

module.exports = { mod: new FancyM9() }
